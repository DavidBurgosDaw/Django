from django.apps import AppConfig


class GestionBecasConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'gestion_becas'
